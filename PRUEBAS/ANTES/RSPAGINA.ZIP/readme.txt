CODIGO DE www.ASPfacil.com
--------------------------

ASPF�cil.com no se hace responsable del uso indebido o de los problemas derivados del uso de este script.
ASPF�cil no se responsabiliza en ning�n caso de...

�ES BROMA!

Nada, que disfrut�is del c�digo, y si plane�is usarlo en alg�n sitio on-line, mandadme una l�nea para que
le eche un ojo aqu�:

webmaster@aspfacil.com

--------------------------------------------------------------
Gracias por visitar www.ASPFacil.com
"el primer sitio dedicado a ASP en espa�ol"
